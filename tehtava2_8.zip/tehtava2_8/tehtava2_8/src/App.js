import React from 'react'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      henkilot: [
        { nimi: 'Arto Hellas',
        numero: '050 1234567',
        id: 1}
      ],
      uusiNimi: '',
      uusiNumero: ''
    }
  }

  lisaaHenkilo = (event) => {
    event.preventDefault()
    const nimilista = this.state.henkilot.map((henkilonNimi) => (henkilonNimi.nimi));
    if (!nimilista.includes(this.state.uusiNimi)) {
      const henkiloOlio = {
        nimi: this.state.uusiNimi,
        numero: this.state.uusiNumero,
        id: this.state.henkilot.length + 1
      }
      
      const henkilot = this.state.henkilot.concat(henkiloOlio)

      this.setState({
        henkilot: henkilot,
        uusiNimi: '',
        uusiNumero: ''
      })
    }    
  }

  uudenHenkilonKasittelija = (event) => {
    this.setState({ uusiNimi: event.target.value })
  }

  uudenNumeronKasittelija = (event) => {
    this.setState({ uusiNumero: event.target.value })
  }
  
  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.lisaaHenkilo}>
          <div>
            nimi: <input 
            value={this.state.uusiNimi}
            onChange={this.uudenHenkilonKasittelija}
            />
          </div>
          <div>
            numero: <input
            value={this.state.uusiNumero}
            onChange={this.uudenNumeronKasittelija}
            />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
          <table>
            <tbody>
              {this.state.henkilot.map(henkilo => <tr key={henkilo.id}><td>{henkilo.nimi}</td><td>{henkilo.numero}</td></tr>)}
            </tbody>
          </table>
      </div>
    )
  }
}
  
  export default App