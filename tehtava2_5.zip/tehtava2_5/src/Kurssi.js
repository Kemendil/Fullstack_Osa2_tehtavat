import React from 'react'

const Kurssit = (props) => {
    const { kurssit } = props;
    const Kurssi = (props) => {
        const { kurssi } = props;
        const Otsikko = (props) => {                                    
            return (
                <div>
                    <h1>{kurssi.nimi}</h1>
                </div>
            )
        }   
    
        const Sisalto = (props) => {        
            const Osa = (props) => {
                return (
                    <div>
                        <p> {props.osa} {props.tehtavia} </p>
                    </div>
                )
            }
            const Yhteensa = (props) => {
                const yhteensa = kurssi.osat.reduce((summa, nykyinen) => summa + nykyinen.tehtavia, 0);
                
                return (
                    <div>
                        <p> yhteensä {yhteensa} tehtävää </p>
                    </div>
                )
            }
        
            return (          
                <div>
                    {kurssi.osat.map(rivi => <Osa key={rivi.id} osa={rivi.nimi} tehtavia={rivi.tehtavia} />)}
                    <Yhteensa />
                </div>
            )
        }

        return (
            <div>
                <Otsikko />
                <Sisalto />
            </div>
        )               
    }

    return (
        <div>
            {kurssit.map(rivi => <Kurssi key={rivi.id} kurssi={rivi} />)}
        </div>
    )
}    

export default Kurssit