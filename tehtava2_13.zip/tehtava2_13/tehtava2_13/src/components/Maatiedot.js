import React from 'react'

const Maatiedot = (props) => {
  let lipputeksti = props.nimi + 's flag'
  return (
    <div>
      <h2>{props.nimi} {props.paikallinenNimi}</h2>
      <p>capital: {props.paakaupunki}</p>
      <p>population: {props.vaesto}</p>
      <img src={props.lippu} alt={lipputeksti} />
    </div>
  )  
}

  export default Maatiedot