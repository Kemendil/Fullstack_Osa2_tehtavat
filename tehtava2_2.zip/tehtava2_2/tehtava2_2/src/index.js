import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {    
    const kurssi = {
        nimi: 'Half Stack -sovelluskehitys',
        osat: [
        {
            nimi: 'Reactin perusteet',
            tehtavia: 10,
            id: 1
          },
          {
            nimi: 'Tiedonvälitys propseilla',
            tehtavia: 7,
            id: 2
          },
          {
            nimi: 'Komponenttien tila',
            tehtavia: 14,
            id: 3
          }
        ]

    }    
    
    const Kurssi = (props) => {
        const { kurssi } = props;
        const Otsikko = (props) => {                                    
            return (
                <div>
                    <h1>{kurssi.nimi}</h1>
                </div>
            )
        }   
        
        const Sisalto = (props) => {        
            const Osa = (props) => {
                return (
                    <div>
                        <p> {props.osa} {props.tehtavia} </p>
                    </div>
                )
            }

            const Yhteensa = (props) => {
                let summa = 0
                kurssi.osat.forEach((osa) => {
                summa+=(osa).tehtavia  
                })

                return (
                    <div>
                        <p> yhteensä {summa} tehtävää </p>
                    </div>
                )
            }
            
            return (          
                <div>
                    {kurssi.osat.map(rivi => <Osa key={rivi.id} osa={rivi.nimi} tehtavia={rivi.tehtavia} />)}
                    <Yhteensa />
                </div>
            )
        }

        return (
            <div>
                <Otsikko />
                <Sisalto />
            </div>
        )
                
    }

    return (
        <div>
            <Kurssi kurssi={kurssi}/>
        </div>
    )
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
)
