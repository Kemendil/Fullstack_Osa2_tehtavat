import React from 'react'
import ReactDOM from 'react-dom'

const App = () => {    
    const kurssit = [
        {
            nimi: 'Half Stack -sovelluskehitys',
            id: 1,
            osat: [
                {
                    nimi: 'Reactin perusteet',
                    tehtavia: 10,
                    id: 1
                },
                {
                    nimi: 'Tiedonvälitys propseilla',
                    tehtavia: 7,
                    id: 2
                },
                {
                    nimi: 'Komponenttien tila',
                    tehtavia: 14,
                    id: 3
                }
            ]

        },
        {
            nimi: 'Node.js',
            id: 2,
            osat: [
                {
                    nimi: 'Routing',
                    tehtavia: 3,
                    id: 1
                },
                {
                    nimi: 'Middlewaret',
                    tehtavia: 7,
                    id: 2
                }
            ]
                      
        }
    ]    
    const Kurssit = (props) => {
        const { kurssit } = props;
        const Kurssi = (props) => {
            const { kurssi } = props;
            const Otsikko = (props) => {                                    
                return (
                    <div>
                        <h1>{kurssi.nimi}</h1>
                    </div>
                )
            }   
        
            const Sisalto = (props) => {        
                const Osa = (props) => {
                    return (
                        <div>
                            <p> {props.osa} {props.tehtavia} </p>
                        </div>
                    )
                }
                const Yhteensa = (props) => {
                    const yhteensa = kurssi.osat.reduce((summa, nykyinen) => summa + nykyinen.tehtavia, 0);
                    
                    return (
                        <div>
                            <p> yhteensä {yhteensa} tehtävää </p>
                        </div>
                    )
                }
            
                return (          
                    <div>
                        {kurssi.osat.map(rivi => <Osa key={rivi.id} osa={rivi.nimi} tehtavia={rivi.tehtavia} />)}
                        <Yhteensa />
                    </div>
                )
            }

            return (
                <div>
                    <Otsikko />
                    <Sisalto />
                </div>
            )               
        }

        return (
            <div>
                {kurssit.map(rivi => <Kurssi key={rivi.id} kurssi={rivi} />)}
            </div>
        )
    }    

    return (
        <div>
            <Kurssit kurssit={kurssit}/>
        </div>
    )
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
)
