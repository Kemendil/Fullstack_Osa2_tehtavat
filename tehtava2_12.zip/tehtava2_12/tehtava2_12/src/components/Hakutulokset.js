import React from 'react'
import Maatiedot from './Maatiedot'

const Hakutulokset = (props) => {
  const tuloksia = props.hakutuloksia
  const maat = [...props.naytettavat]
  if (tuloksia >= 10) {
    return (
      <div>
        <p>to many maches, specify another filter</p>
      </div>
    )  
  } else if (tuloksia > 1) {
    return (
      <div>
        {maat.map(maa => <p key={maa.alpha2Code}>{maa.name}</p>)}
      </div>
    )  
  } else if (tuloksia === 1) {
    return (
      <div>
        <Maatiedot
          nimi={maat[0].name}
          paikallinenNimi={maat[0].altSpellings[1]}
          paakaupunki={maat[0].capital}
          vaesto={maat[0].population}
          lippu={maat[0].flag}
        />
      </div>
    )  
  }
  return (
    <div></div>
  )  
}

  export default Hakutulokset