import React from 'react'

const Hakukentta = (props) => {
  return (
    <div>
      <form>
        <div>
          find countries: <input 
            value={props.hakusana}
            onChange={props.hakusananKasittelija}
            />
        </div>
      </form>
    </div>
  )  
}

  export default Hakukentta
  