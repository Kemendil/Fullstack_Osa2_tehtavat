import React from 'react';
import axios from 'axios';
import Hakutulokset from './components/Hakutulokset'
import Hakukentta from './components/Hakukentta'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      maat: [],
      naytettavat: [],
      hakusana: ''
    }

    setInterval(() => {
      this.rajaaHakua()}, 500)
  }
  
  componentDidMount() {
    axios
      .get('https://restcountries.eu/rest/v2/all')
      .then(vastaus => {
        this.setState({ maat: vastaus.data})
      })
  }

  rajaaHakua = (event) => {
    const tasmaavatMaat = []
    for (let i = 0; i < this.state.maat.length; i++) {
      const maanNimiPienella = this.state.maat[i].name.toLowerCase()
      const hakusanaPienella = this.state.hakusana.toLowerCase()
      if (maanNimiPienella.includes(hakusanaPienella)) {
        tasmaavatMaat.push(this.state.maat[i])
      }
    }
    this.setState({ naytettavat: tasmaavatMaat})
  }

  hakusananKasittelija = (event) => {
    this.setState({ hakusana: event.target.value})
  }

  render() {
    return (
      <div>
        <div>
          <Hakukentta
            hakusana={this.state.hakusana}
            hakusananKasittelija={this.hakusananKasittelija}
          />
        </div>
        <div>
          <Hakutulokset
            hakutuloksia={this.state.naytettavat.length}
            naytettavat={this.state.naytettavat}
          />
        </div>
      </div>
    )
  }
}

export default App;
