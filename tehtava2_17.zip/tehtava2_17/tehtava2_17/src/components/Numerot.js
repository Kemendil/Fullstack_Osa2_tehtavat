import React from 'react'

const Numerot = (props) => {
  return (
    <div>
      <table>
        <tbody>
          {props.naytettavat.map(henkilo => <tr key={henkilo.id}><td>{henkilo.nimi}</td><td>{henkilo.numero}</td><td><button type="submit" onClick={() => props.poistaja(henkilo)}>poista</button></td></tr>)}
        </tbody>
      </table>      
    </div>
  )
}

export default Numerot