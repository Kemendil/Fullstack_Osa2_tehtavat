import React from 'react'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      henkilot: [
        { nimi: 'Arto Hellas',
          id: 1}
      ],
      uusiNimi: '',
      idNumero: 1
    }
  }

  lisaaHenkilo = (event) => {
    event.preventDefault()
    const nimilista = this.state.henkilot.map((henkilonNimi) => (henkilonNimi.nimi));
    if (!nimilista.includes(this.state.uusiNimi)) {
      const henkiloOlio = {
        nimi: this.state.uusiNimi,
        id: this.state.henkilot.length + 1
      }
      
      const henkilot = this.state.henkilot.concat(henkiloOlio)

      this.setState({
        henkilot: henkilot,
        uusiNimi: ''
      })
    }    
  }

  uudenHenkilonKasittelija = (event) => {
    console.log(event.target.value)
    this.setState({ uusiNimi: event.target.value })
  }
  
  render() {
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form onSubmit={this.lisaaHenkilo}>
          <div>
            nimi: <input 
            value={this.state.uusiNimi}
            onChange={this.uudenHenkilonKasittelija}
            />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
          {this.state.henkilot.map(henkilo => <p key={henkilo.id}>{henkilo.nimi}</p>)}
      </div>
    )
  }
}
  
  export default App