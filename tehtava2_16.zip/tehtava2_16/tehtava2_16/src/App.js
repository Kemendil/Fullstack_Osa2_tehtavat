import React from 'react'
import Henkilokaavake from './components/Henkilokaavake'
import Rajaus from './components/Rajaus'
import Numerot from './components/Numerot'
import henkilopalvelu from './services/henkilot'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      henkilot: [],
      uusiNimi: '',
      uusiNumero: '',
      hakusana: '',
      naytaKaikki: true
    }

    setInterval(() => {
      this.rajaaHakua()}, 500)
  }

  componentDidMount() {
    henkilopalvelu
      .lataaKaikki()
      .then(vastaus => {
        this.setState( {henkilot: vastaus.data})
      })
  }

  lisaaHenkilo = (event) => {
    event.preventDefault()
    const nimilista = this.state.henkilot.map((henkilonNimi) => (henkilonNimi.nimi));
    if (!nimilista.includes(this.state.uusiNimi)) {
      const henkiloOlio = {
        nimi: this.state.uusiNimi,
        numero: this.state.uusiNumero,
        vastaaHakusanaa: true
      }
        
      henkilopalvelu
        .luo(henkiloOlio)
        .then(vastaus => {
          henkilopalvelu
            .lataaKaikki()
            .then(vastaus => {
              this.setState( {henkilot: vastaus.data})
            })
          this.setState({
            uusiNimi: '',
            uusiNumero: ''
          })
      })  
    }    
  }

  uudenHenkilonKasittelija = (event) => {
    this.setState({ uusiNimi: event.target.value })
  }

  uudenNumeronKasittelija = (event) => {
    this.setState({ uusiNumero: event.target.value })
  }

  rajaaHakua = (event) => {
    if (this.state.hakusana.length === 0) {
      this.setState({ naytaKaikki: true})
    } else {
      this.setState({ naytaKaikki: false})      
      const henkilotKopio = [...this.state.henkilot]
      for (let i = 0; i < henkilotKopio.length; i++) {
        const henkilonNimiPienella = henkilotKopio[i].nimi.toLowerCase()
        const hakusanaPienella = this.state.hakusana.toLowerCase()
        if (!henkilonNimiPienella.includes(hakusanaPienella)) {
          henkilotKopio[i].vastaaHakusanaa = false
        } else if (henkilonNimiPienella.includes(hakusanaPienella)) {
          henkilotKopio[i].vastaaHakusanaa = true
        }
      }
      this.setState({ henkilot: henkilotKopio})
    }
  }

  hakusananKasittelija = (event) => {
    this.setState({ hakusana: event.target.value})
  }

  poistaja = (henkilo) => {
    if (window.confirm('Poistetaanko ' + henkilo.nimi + '?')) {
      henkilopalvelu
        .poista(henkilo)
        .then(vastaus => {
          henkilopalvelu
            .lataaKaikki()
            .then(vastaus => {
            this.setState( {henkilot: vastaus.data})
            })  
        })       
    }
  } 

  render() {
    const naytettavat =
      this.state.naytaKaikki ?
        this.state.henkilot :
        this.state.henkilot.filter(henkilo => henkilo.vastaaHakusanaa === true)
            
    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <Rajaus 
          rajaaHakua={this.rajaaHakua}
          hakusana={this.state.hakusana}
          hakusananKasittelija={this.hakusananKasittelija}
          poistaRajaus={this.poistaRajaus}            
          />
        <Henkilokaavake 
          lisaaHenkilo={this.lisaaHenkilo}
          uusiNimi={this.state.uusiNimi}
          uusiNumero={this.state.uusiNumero}
          uudenHenkilonKasittelija={this.uudenHenkilonKasittelija}
          uudenNumeronKasittelija={this.uudenNumeronKasittelija}
          />
        <Numerot 
          naytettavat={naytettavat}
          poistaja={this.poistaja}
          />
      </div>
    )
  }
}
  
  export default App