import React from 'react'

const Henkilokaavake = (props) => {
    return (
    <div>
      <h2>Lisää uusi</h2>
      <form onSubmit={props.lisaaHenkilo}>            
        <div>
          nimi: <input 
          value={props.uusiNimi}
          onChange={props.uudenHenkilonKasittelija}
          />
        </div>
        <div>
          numero: <input 
          value={props.uusiNumero}
          onChange={props.uudenNumeronKasittelija}
          />
        </div>
        <div>
          <button type="submit">lisää</button>
        </div>
      </form>
    </div>
    )
  }

 export default Henkilokaavake  