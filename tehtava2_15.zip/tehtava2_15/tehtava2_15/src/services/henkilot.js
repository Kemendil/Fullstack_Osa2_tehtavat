import axios from 'axios'
const baseUrl = 'http://localhost:3001/henkilot'

const lataaKaikki = () => {
    return axios.get(baseUrl)
}

const luo = (uusiOlio) => {
    return axios.post(baseUrl, uusiOlio)
}

export default { lataaKaikki, luo }