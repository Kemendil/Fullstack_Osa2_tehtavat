import React from 'react'

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      henkilot: [
        { nimi: 'Arto Hellas',
        numero: '050 1234567',
        id: 1,
        vastaaHakusanaa: true}
      ],
      uusiNimi: '',
      uusiNumero: '',
      hakusana: '',
      naytaKaikki: false
    }

    setInterval(() => {
      this.rajaaHakua()}, 500)
  }

  lisaaHenkilo = (event) => {
    event.preventDefault()
    const nimilista = this.state.henkilot.map((henkilonNimi) => (henkilonNimi.nimi));
    if (!nimilista.includes(this.state.uusiNimi)) {
      const henkiloOlio = {
        nimi: this.state.uusiNimi,
        numero: this.state.uusiNumero,
        id: this.state.henkilot.length + 1,
        vastaaHakusanaa: true
      }
      
      const henkilot = this.state.henkilot.concat(henkiloOlio)

      this.setState({
        henkilot: henkilot,
        uusiNimi: '',
        uusiNumero: ''
      })
    }    
  }

  uudenHenkilonKasittelija = (event) => {
    this.setState({ uusiNimi: event.target.value })
  }

  uudenNumeronKasittelija = (event) => {
    this.setState({ uusiNumero: event.target.value })
  }

  rajaaHakua = (event) => {
    if (this.state.hakusana.length === 0) {
      this.setState({ naytaKaikki: true})
    } else {
      this.setState({ naytaKaikki: false})
    }
    const henkilotKopio = [...this.state.henkilot]
    for (let i = 0; i < henkilotKopio.length; i++) {
      const henkilonNimiPienella = henkilotKopio[i].nimi.toLowerCase()
      const hakusanaPienella = this.state.hakusana.toLowerCase()
      if (!henkilonNimiPienella.includes(hakusanaPienella)) {
        henkilotKopio[i].vastaaHakusanaa = false
      } else if (henkilonNimiPienella.includes(hakusanaPienella)) {
        henkilotKopio[i].vastaaHakusanaa = true
      }
    }
    this.setState({ henkilot: henkilotKopio})
  }

  hakusananKasittelija = (event) => {
    this.setState({ hakusana: event.target.value})
  }
  
  render() {
    const naytettavat =
      this.state.naytaKaikki ?
        this.state.henkilot :
        this.state.henkilot.filter(henkilo => henkilo.vastaaHakusanaa === true)

    return (
      <div>
        <h2>Puhelinluettelo</h2>
        <form>
          <div>
            rajaa näytettäviä<input 
            value={this.state.hakusana}
            onChange={this.hakusananKasittelija}
            />
          </div>
        </form>
        <h2>Lisää uusi</h2>
        <form onSubmit={this.lisaaHenkilo}>            
          <div>
            nimi: <input 
            value={this.state.uusiNimi}
            onChange={this.uudenHenkilonKasittelija}
            />
          </div>
          <div>
            numero: <input
            value={this.state.uusiNumero}
            onChange={this.uudenNumeronKasittelija}
            />
          </div>
          <div>
            <button type="submit">lisää</button>
          </div>
        </form>
        <h2>Numerot</h2>
          <table>
            <tbody>
              {naytettavat.map(henkilo => <tr key={henkilo.id}><td>{henkilo.nimi}</td><td>{henkilo.numero}</td></tr>)}
            </tbody>
          </table>
      </div>
    )
  }
}
  
  export default App